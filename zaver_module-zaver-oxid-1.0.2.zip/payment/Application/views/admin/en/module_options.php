<?php
/**
 * Copyright © Zaver B2B. All rights reserved.
 */
$sLangName = 'English';

$aLang = array(
  'charset' => 'utf-8',
  // Zaver module
  'zaver' => 'Zaver',
  'ZAVER' => 'Zaver',
  'SHOP_MODULE_GROUP_zaver_settings' => 'Payment configuration',
  'SHOP_MODULE_ZV_HOSTURL' => 'Host URL',
  'HELP_SHOP_MODULE_ZV_HOSTURL' => 'Enter zaver Host URL',
  'SHOP_MODULE_ZV_APIKEY' => 'API-Key',
  'HELP_SHOP_MODULE_ZV_APIKEY' => 'Enter zaver API-Key',
  'SHOP_MODULE_GROUP_ZAVER_GENERAL' => 'Zaver Oxid',
  'SHOP_MODULE_ZaverOxid' => 'Please configure via the separate Zaver menu item'
);
