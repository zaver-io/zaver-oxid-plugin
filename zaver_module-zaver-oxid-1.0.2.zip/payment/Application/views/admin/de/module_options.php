<?php
/**
 * Copyright © Zaver B2B. All rights reserved.
 */
$sLangName = 'Deutsch';

$aLang = array(
  'charset' => 'utf-8',
  // Zaver module
  'zaver' => 'Zaver',
  'ZAVER' => 'Zaver',
  'SHOP_MODULE_GROUP_zaver_settings' => 'Zaver Allgemeine Konfiguration',
  'SHOP_MODULE_ZV_HOSTURL' => 'Host URL',
  'HELP_SHOP_MODULE_ZV_HOSTURL' => 'Host URL Schlüssel',
  'SHOP_MODULE_ZV_APIKEY' => 'API-Key',
  'HELP_SHOP_MODULE_ZV_APIKEY' => 'API-Key Schlüssel',
  'SHOP_MODULE_GROUP_ZAVER_GENERAL' => 'Zaver Oxid',
  'SHOP_MODULE_ZaverOxid' => 'Bitte über den separaten Zaver-Menüpunkt konfigurieren'
);
