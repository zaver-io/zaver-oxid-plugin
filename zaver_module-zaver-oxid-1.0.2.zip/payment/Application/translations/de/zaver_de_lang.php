<?php
$sLangName = 'Deutsch';

$aLang = array(
  'charset' => 'utf-8',
  // Zaver module
  'ZV_PAYMENT_CANCEL_TXT' => 'Die Bezahlung wurde abgrebrochen.',
  'ZV_PAYMENT_ERROR_TXT' => 'Es ist ein Fehler aufgetreten.',
  'ZV_PAYMENT_CREATED_TXT' => 'Die Bezahlung wurde im Zaver-Bezahlsystem angelegt und wartet nun auf Buchung.',
  'ZV_PAYMENT_NOTVALID_TXT' => 'Gewählte Zahlungsart ist für diese Bestellung unzulässig.',
  'ZV_PAYMENT_SETTINGS_EMPTY' => 'Die Zahlungseinstellungen sind leer.'
);