<?php
$sLangName = 'English';

$aLang = array(
  'charset' => 'utf-8',
  // Zaver module
  'ZV_PAYMENT_CANCEL_TXT' => 'The payment has been cancelled.',
  'ZV_PAYMENT_ERROR_TXT' => 'An error occurred.',
  'ZV_PAYMENT_CREATED_TXT' => 'The payment has been created in the Zaver payment system, and is awaiting settlement.',
  'ZV_PAYMENT_NOTVALID_TXT' => 'Parameter payment method not valid for order.',
  'ZV_PAYMENT_SETTINGS_EMPTY' => 'The payment settings are empty.'
);
